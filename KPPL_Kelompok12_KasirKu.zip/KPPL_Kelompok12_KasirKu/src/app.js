import {
  addToCart,
  calculateTotals,
  changeCartQuantity,
  completeCheckout,
  filterProducts,
  findProduct,
  formatRupiah,
  getStockStatus,
} from "./inventory.js";
import { loadState, resetState, saveState } from "./storage.js";

let state = loadState();
let query = "";
let selectedCategory = "Semua";

const productGrid = document.querySelector("#productGrid");
const cartItems = document.querySelector("#cartItems");
const historyList = document.querySelector("#historyList");
const searchInput = document.querySelector("#searchInput");
const categorySelect = document.querySelector("#categorySelect");
const memberCheckbox = document.querySelector("#memberCheckbox");
const checkoutButton = document.querySelector("#checkoutButton");
const toast = document.querySelector("#toast");

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[character]);
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("visible");
  window.clearTimeout(showToast.timerId);
  showToast.timerId = window.setTimeout(() => toast.classList.remove("visible"), 2800);
}

function renderSummary() {
  const lowStock = state.products.filter((product) => product.stock <= 5).length;
  const salesRevenue = state.orders.reduce((total, order) => total + order.total, 0);
  const totals = calculateTotals(state.cart, state.products, state.isMember);
  document.querySelector("#metricProducts").textContent = state.products.length;
  document.querySelector("#metricLowStock").textContent = lowStock;
  document.querySelector("#metricCart").textContent = totals.itemCount;
  document.querySelector("#metricRevenue").textContent = formatRupiah(salesRevenue);
}

function renderProducts() {
  const products = filterProducts(state.products, query, selectedCategory);
  document.querySelector("#resultCount").textContent = `${products.length} produk ditemukan`;
  if (products.length === 0) {
    productGrid.innerHTML = '<p class="empty-state">Produk tidak ditemukan. Coba kata kunci lain.</p>';
    return;
  }
  productGrid.innerHTML = products.map((product) => {
    const status = getStockStatus(product.stock);
    const stockLabel = status === "habis" ? "Stok habis" : status === "menipis" ? "Stok menipis" : "Stok tersedia";
    return `<article class="product-card">
      <div class="product-visual" aria-hidden="true">${escapeHtml(product.emoji)}</div>
      <div class="product-info">
        <span class="category">${escapeHtml(product.category)}</span>
        <h3>${escapeHtml(product.name)}</h3>
        <p class="price">${formatRupiah(product.price)}</p>
        <span class="stock ${status}">${stockLabel} (${product.stock})</span>
      </div>
      <div class="product-actions">
        <button class="button button-primary button-small" data-add="${product.id}" ${product.stock === 0 ? "disabled" : ""}>+ Keranjang</button>
        <button class="button button-outline button-small" data-restock="${product.id}" title="Tambah stok 5 unit">+5 Stok</button>
      </div>
    </article>`;
  }).join("");
}

function renderCart() {
  const totals = calculateTotals(state.cart, state.products, state.isMember);
  if (state.cart.length === 0) {
    cartItems.innerHTML = '<div class="cart-empty">🛒<p>Keranjang masih kosong.</p><small>Tambahkan produk dari katalog.</small></div>';
  } else {
    cartItems.innerHTML = state.cart.map((item) => {
      const product = findProduct(state.products, item.productId);
      if (!product) {
        return "";
      }
      return `<div class="cart-item">
        <div class="cart-emoji">${escapeHtml(product.emoji)}</div>
        <div class="cart-description">
          <strong>${escapeHtml(product.name)}</strong>
          <span>${formatRupiah(product.price)}</span>
          <div class="quantity-control">
            <button aria-label="Kurangi ${escapeHtml(product.name)}" data-minus="${product.id}">−</button>
            <span>${item.qty}</span>
            <button aria-label="Tambah ${escapeHtml(product.name)}" data-plus="${product.id}" ${item.qty >= product.stock ? "disabled" : ""}>+</button>
          </div>
        </div>
        <strong class="line-total">${formatRupiah(product.price * item.qty)}</strong>
      </div>`;
    }).join("");
  }
  document.querySelector("#subtotal").textContent = formatRupiah(totals.subtotal);
  document.querySelector("#discount").textContent = `− ${formatRupiah(totals.discount)}`;
  document.querySelector("#grandTotal").textContent = formatRupiah(totals.total);
  memberCheckbox.checked = state.isMember;
  checkoutButton.disabled = state.cart.length === 0;
}

function renderHistory() {
  if (state.orders.length === 0) {
    historyList.innerHTML = '<p class="history-empty">Belum ada transaksi. Coba lakukan checkout pertama.</p>';
    return;
  }
  historyList.innerHTML = state.orders.slice(0, 5).map((order) => {
    const date = new Date(order.timestamp).toLocaleString("id-ID", { dateStyle: "medium", timeStyle: "short" });
    return `<div class="history-item"><div><strong>${escapeHtml(order.id)}</strong><small>${date} · ${order.itemCount} barang${order.isMember ? " · Member" : ""}</small></div><b>${formatRupiah(order.total)}</b></div>`;
  }).join("");
}

function render() {
  renderSummary();
  renderProducts();
  renderCart();
  renderHistory();
}

function persistAndRender() {
  saveState(state);
  render();
}

productGrid.addEventListener("click", (event) => {
  const addButton = event.target.closest("[data-add]");
  const restockButton = event.target.closest("[data-restock]");
  if (addButton) {
    const id = Number(addButton.dataset.add);
    const previousCart = state.cart;
    state = { ...state, cart: addToCart(state.cart, state.products, id) };
    showToast(state.cart === previousCart ? "Jumlah sudah mencapai stok tersedia." : "Produk berhasil ditambahkan.");
    persistAndRender();
  }
  if (restockButton) {
    const id = Number(restockButton.dataset.restock);
    state = { ...state, products: state.products.map((product) => product.id === id ? { ...product, stock: product.stock + 5 } : product) };
    showToast("Stok produk bertambah 5 unit.");
    persistAndRender();
  }
});

cartItems.addEventListener("click", (event) => {
  const plus = event.target.closest("[data-plus]");
  const minus = event.target.closest("[data-minus]");
  if (!plus && !minus) {
    return;
  }
  const id = Number(plus ? plus.dataset.plus : minus.dataset.minus);
  state = { ...state, cart: changeCartQuantity(state.cart, state.products, id, plus ? 1 : -1) };
  persistAndRender();
});

searchInput.addEventListener("input", (event) => {
  query = event.target.value;
  renderProducts();
});
categorySelect.addEventListener("change", (event) => {
  selectedCategory = event.target.value;
  renderProducts();
});
memberCheckbox.addEventListener("change", (event) => {
  state = { ...state, isMember: event.target.checked };
  persistAndRender();
});
checkoutButton.addEventListener("click", () => {
  const result = completeCheckout(state.cart, state.products, state.isMember, `TRX-${Date.now()}`);
  if (!result.ok) {
    showToast(result.error);
    return;
  }
  state = { ...state, products: result.products, cart: [], orders: [result.order, ...state.orders] };
  showToast(`Transaksi ${result.order.id} berhasil disimpan.`);
  persistAndRender();
});

document.querySelector("#resetButton").addEventListener("click", () => {
  if (!window.confirm("Reset seluruh produk, keranjang, dan transaksi ke data awal?")) {
    return;
  }
  state = resetState();
  query = "";
  selectedCategory = "Semua";
  searchInput.value = "";
  categorySelect.value = "Semua";
  showToast("Data latihan berhasil direset.");
  render();
});

render();
