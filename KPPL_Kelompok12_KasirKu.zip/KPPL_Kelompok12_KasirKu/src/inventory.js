

export function formatRupiah(value) {
  const nominal = Number(value) || 0;
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(nominal);
}

export function getStockStatus(stock) {
  if (stock === 0) {
  return "habis";
}
  if (stock <= 5) {return "menipis";}
  return "tersedia";
}

export function clampQuantity(value) {
  const quantity = Number(value);
  if (!Number.isFinite(quantity)) {return 0;}
  return Math.max(0, Math.floor(quantity));
}

export function findProduct(products, id) {
  return products.find((product) => product.id === Number(id));
}

export function filterProducts(products, query = "", category = "Semua") {
  const term = String(query).trim().toLocaleLowerCase("id-ID");
  return products.filter((product) => {
    const matchName = product.name.toLocaleLowerCase("id-ID").includes(term);
    const matchCategory = category === "Semua" || product.category === category;
    return matchName && matchCategory;
  });
}

export function addToCart(cart, products, id) {
  const product = findProduct(products, id);
  if (!product || product.stock <= 0) {return cart;}
  const current = cart.find((item) => item.productId === product.id);
  if (current && current.qty >= product.stock) {return cart;}
  if (current) {
    return cart.map((item) =>
      item.productId === product.id ? { ...item, qty: item.qty + 1 } : item,
    );
  }
  return [...cart, { productId: product.id, qty: 1 }];
}

export function changeCartQuantity(cart, products, id, difference) {
  const product = findProduct(products, id);
  if (!product) {return cart;}
  return cart
    .map((item) => {
      if (item.productId !== product.id) {return item;}
      const quantity = clampQuantity(item.qty + difference);
      return { ...item, qty: Math.min(quantity, product.stock) };
    })
    .filter((item) => item.qty > 0);
}

export function calculateTotals(cart, products, isMember = false) {
  let subtotal = 0;
  let itemCount = 0;
  for (const item of cart) {
    const product = findProduct(products, item.productId);
    if (product) {
      subtotal += product.price * item.qty;
      itemCount += item.qty;
    }
  }
  const discount = isMember ? Math.round(subtotal * 0.1) : 0;
  return { subtotal, discount, total: subtotal - discount, itemCount };
}

export function completeCheckout(cart, products, isMember = false, orderId = "TRX-001", timestamp = new Date().toISOString()) {
  if (cart.length === 0) {return { ok: false, error: "Keranjang masih kosong." };}
  for (const item of cart) {
    const product = findProduct(products, item.productId);
    if (!product || item.qty <= 0 || item.qty > product.stock) {
      return { ok: false, error: "Stok barang tidak mencukupi." };
    }
  }
  const totals = calculateTotals(cart, products, isMember);
  const updatedProducts = products.map((product) => {
    const cartItem = cart.find((item) => item.productId === product.id);
    return cartItem ? { ...product, stock: product.stock - cartItem.qty } : { ...product };
  });
  const order = {
    id: orderId,
    timestamp,
    isMember,
    items: cart.map((item) => {
      const product = findProduct(products, item.productId);
      return { name: product.name, qty: item.qty, price: product.price };
    }),
    ...totals,
  };
  return { ok: true, products: updatedProducts, order };
}
