const STORAGE_KEY = "kppl-kasirku-mini-v1";

export const SEED_PRODUCTS = [
  { id: 1, name: "Kopi Arabika", category: "Minuman", price: 28000, stock: 12, emoji: "☕" },
  { id: 2, name: "Teh Melati", category: "Minuman", price: 12000, stock: 8, emoji: "🍵" },
  { id: 3, name: "Air Mineral", category: "Minuman", price: 5000, stock: 35, emoji: "💧" },
  { id: 4, name: "Roti Gandum", category: "Makanan", price: 18000, stock: 15, emoji: "🍞" },
  { id: 5, name: "Cokelat Batang", category: "Makanan", price: 14000, stock: 5, emoji: "🍫" },
  { id: 6, name: "Keripik Singkong", category: "Makanan", price: 10000, stock: 4, emoji: "🥔" },
  { id: 7, name: "Susu UHT", category: "Minuman", price: 16000, stock: 0, emoji: "🥛" },
  { id: 8, name: "Biskuit", category: "Makanan", price: 8500, stock: 20, emoji: "🍪" },
  { id: 9, name: "Mi Instan", category: "Makanan", price: 3500, stock: 55, emoji: "🍜" },
];

export function createInitialState() {
  return {
    products: SEED_PRODUCTS.map((product) => ({ ...product })),
    cart: [],
    orders: [],
    isMember: false,
  };
}

export function loadState() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return createInitialState();
    }
    const state = JSON.parse(raw);
    if (!Array.isArray(state.products) || !Array.isArray(state.cart) || !Array.isArray(state.orders)) {
      return createInitialState();
    }
    return { ...state, isMember: Boolean(state.isMember) };
  } catch {
    return createInitialState();
  }
}

export function saveState(state) {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function resetState() {
  window.localStorage.removeItem(STORAGE_KEY);
  return createInitialState();
}
