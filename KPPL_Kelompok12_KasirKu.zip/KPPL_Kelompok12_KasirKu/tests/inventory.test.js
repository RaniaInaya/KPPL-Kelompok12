import test from "node:test";
import assert from "node:assert/strict";
import {
  addToCart,
  calculateTotals,
  changeCartQuantity,
  clampQuantity,
  completeCheckout,
  filterProducts,
  findProduct,
  getStockStatus,
} from "../src/inventory.js";

const products = [
  { id: 1, name: "Kopi Arabika", category: "Minuman", price: 28000, stock: 12 },
  { id: 2, name: "Roti Gandum", category: "Makanan", price: 18000, stock: 2 },
  { id: 3, name: "Susu UHT", category: "Minuman", price: 16000, stock: 0 },
];

test("TC-F01: jumlah barang dibulatkan dan tidak negatif", () => {
  assert.equal(clampQuantity(2.9), 2);
  assert.equal(clampQuantity(-5), 0);
  assert.equal(clampQuantity("salah"), 0);
});

test("TC-F02: status stok tersedia, menipis, dan habis", () => {
  assert.equal(getStockStatus(12), "tersedia");
  assert.equal(getStockStatus(2), "menipis");
  assert.equal(getStockStatus(0), "habis");
});

test("TC-F03: pencarian nama dan kategori", () => {
  assert.equal(filterProducts(products, "kopi", "Semua").length, 1);
  assert.equal(filterProducts(products, "", "Minuman").length, 2);
});

test("TC-F04: identitas produk dapat dicari", () => {
  assert.equal(findProduct(products, 1).name, "Kopi Arabika");
  assert.equal(findProduct(products, 999), undefined);
});

test("TC-F05: tambah produk ke keranjang", () => {
  const cart = addToCart([], products, 1);
  assert.deepEqual(cart, [{ productId: 1, qty: 1 }]);
  assert.equal(addToCart(cart, products, 1)[0].qty, 2);
});

test("TC-F06: produk habis tidak dapat ditambahkan", () => {
  assert.deepEqual(addToCart([], products, 3), []);
});

test("TC-F07: jumlah keranjang tidak boleh melebihi stok", () => {
  const cart = [{ productId: 2, qty: 2 }];
  assert.deepEqual(changeCartQuantity(cart, products, 2, 1), cart);
  assert.deepEqual(changeCartQuantity(cart, products, 2, -2), []);
});

test("TC-F08: subtotal dan diskon member 10%", () => {
  const cart = [{ productId: 1, qty: 2 }, { productId: 2, qty: 1 }];
  assert.deepEqual(calculateTotals(cart, products, false), { subtotal: 74000, discount: 0, total: 74000, itemCount: 3 });
  assert.deepEqual(calculateTotals(cart, products, true), { subtotal: 74000, discount: 7400, total: 66600, itemCount: 3 });
});

test("TC-F09: checkout mengurangi stok dan mencatat transaksi", () => {
  const original = structuredClone(products);
  const result = completeCheckout([{ productId: 1, qty: 2 }], products, true, "TRX-UJI", "2026-11-16T08:00:00.000Z");
  assert.equal(result.ok, true);
  assert.equal(result.products[0].stock, 10);
  assert.equal(result.order.total, 50400);
  assert.equal(result.order.items.length, 1);
  assert.deepEqual(products, original, "Data input tidak boleh ikut berubah (mutasi)");
});

test("TC-F10: checkout ditolak apabila stok tidak mencukupi", () => {
  const result = completeCheckout([{ productId: 2, qty: 3 }], products);
  assert.equal(result.ok, false);
});

test("TC-F11: checkout ditolak jika keranjang kosong", () => {
  const result = completeCheckout([], products);
  assert.equal(result.ok, false);
});

test("TC-F12: identitas produk yang tidak valid tidak dapat checkout", () => {
  const result = completeCheckout([{ productId: 999, qty: 1 }], products);
  assert.equal(result.ok, false);
});
