import { readFile, writeFile } from "node:fs/promises";

let first;
let last;
try {
  first = JSON.parse(await readFile("reports/awal.json", "utf8"));
  last = JSON.parse(await readFile("reports/akhir.json", "utf8"));
} catch {
  console.error("File laporan belum lengkap. Jalankan npm run report:awal dan npm run report:akhir terlebih dahulu.");
  process.exit(1);
}

function summary(items) {
  const errors = items.reduce((sum, item) => sum + item.errorCount, 0);
  const warnings = items.reduce((sum, item) => sum + item.warningCount, 0);
  return { errors, warnings, total: errors + warnings };
}
const before = summary(first);
const after = summary(last);
const improvement = before.total === 0 ? 0 : ((before.total - after.total) / before.total) * 100;
const content = `# Perbandingan Pemeriksaan ESLint\n\n` +
  `| Metrik | Sebelum perbaikan | Sesudah perbaikan |\n|---|---:|---:|\n` +
  `| Error | ${before.errors} | ${after.errors} |\n` +
  `| Warning | ${before.warnings} | ${after.warnings} |\n` +
  `| **Total temuan** | **${before.total}** | **${after.total}** |\n\n` +
  `Penurunan total temuan: **${improvement.toFixed(1)}%**.\n\n` +
  `**Interpretasi:** Hasil ini menunjukkan kepatuhan terhadap aturan ESLint yang dikonfigurasi, BUKAN bukti bahwa perangkat lunak bebas dari semua bug.\n` +
  `Validasi fungsional dilakukan secara terpisah melalui \`npm test\`.\n`;
await writeFile("reports/perbandingan.md", content, "utf8");
console.log(content);
console.log("Disimpan ke reports/perbandingan.md");
