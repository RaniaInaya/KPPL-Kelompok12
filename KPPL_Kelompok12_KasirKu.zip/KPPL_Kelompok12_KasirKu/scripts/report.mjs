import { ESLint } from "eslint";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

const stage = process.argv[2];
if (!["awal", "akhir"].includes(stage)) {
  console.error("Gunakan: node scripts/report.mjs awal | akhir");
  process.exitCode = 1;
} else {
  const eslint = new ESLint({ fix: false });
  const results = await eslint.lintFiles(["src/**/*.js"]);
  const formatter = await eslint.loadFormatter("json");
  await mkdir("reports", { recursive: true });
  await writeFile(path.join("reports", `${stage}.json`), await formatter.format(results), "utf8");
  const errors = results.reduce((sum, file) => sum + file.errorCount, 0);
  const warnings = results.reduce((sum, file) => sum + file.warningCount, 0);
  const rules = new Map();
  for (const result of results) {
    for (const message of result.messages) {
      const name = message.ruleId || "other";
      rules.set(name, (rules.get(name) || 0) + 1);
    }
  }
  console.log(`Laporan ${stage.toUpperCase()} tersimpan: reports/${stage}.json`);
  console.log(`Error: ${errors} | Warning: ${warnings} | Total: ${errors + warnings}`);
  if (rules.size) {
    console.log("Temuan per rule:");
    for (const [name, count] of [...rules.entries()].sort()) {
      console.log(`  ${name}: ${count}`);
    }
  }
}
